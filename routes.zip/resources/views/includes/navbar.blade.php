<nav id="nav-menu-container">
    <ul class="nav-menu">
        <li class="{{--menu-active--}}"><a href="/">Home</a></li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle-mob" href="/" data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">Company <i class="icofont-rounded-down"></i></a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="/companyintro">Company Introduction</a></li>
                <li><a class="dropdown-item" href="/MFChairman">Message From Chairman</a></li>
               {{-- <li><a class="dropdown-item" href="/prd">RRD</a></li>
                <li><a class="dropdown-item" href="/pr">PR</a></li>--}}
            </ul>
        </li>

     {{--   <li><a href="/media">Media</a></li>--}}
        <li><a href="/products">Product</a></li>
       {{-- <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle-mob" href="/career" data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">Career <i class="icofont-rounded-down"></i></a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="/desired">Desired Qualities of Employee Grid</a>
                </li>
                <li><a class="dropdown-item" href="/hr">HR Policy</a></li>
                <li><a class="dropdown-item" href="/recruitment">Recruitment</a></li>
                <li><a class="dropdown-item" href="/information">Information</a></li>
                <li><a class="dropdown-item" href="/apply">Apply</a></li>
            </ul>
        </li>--}}

        <li><a href="/career">Career</a></li>
        <li><a href="/contact">Contact</a></li>
        <li><a href="https://germanchemicalsltd.com:2096">Webmail</a></li>
    </ul>
</nav><!-- #nav-menu-container -->