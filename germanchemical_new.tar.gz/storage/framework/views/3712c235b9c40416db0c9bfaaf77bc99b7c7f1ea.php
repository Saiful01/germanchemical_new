<?php $__env->startSection('title','MfChairman'); ?>



<?php $__env->startSection('content'); ?>

    <section id="services">
        <div class="container">

            <header class="section-header wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                <h3>Message from Chairman</h3>

            </header>

            <div class="row">
                <div class="col-sm-3">

                    <img width="100%" height=""
                         src="/img/Badiul-Alam-Chairman.png"
                         class="img-thumbnail" alt="">
                </div>
                <div class="col-sm-9">

                    <p class="text-justify">
                        Having started a venture 17 (seventeen) years ago, today I am Privileged to be a founding member
                        of one of the most competitive chemical company with emphasis on efficiency in operations,
                        reliability for customers and trust on sustainable development. For us, Sustainability means
                        aligning economic success with environmental and social responsibility.
                        <br>
                        <br>
                        I would like to thank our employees, customers, suppliers and other stakeholders for their
                        dedication and support. We are committed to improve the efficiency in our operations and
                        differentiate ourselves in the market-place through customer focused innovation in product and
                        services, so as to build a stronger and sustainable future for our company and our associates.
                       <br>
                    <!-- <img class=""
                         src="/img/MD-sir-sign.png" alt=""
                         width="150px"> -->


                    <b>Md. Badiul Alam <br>Chairman<br>
                            German Chemicals Limited</b></p>
                    <p></p>

                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/pages/company/MFChairman.blade.php ENDPATH**/ ?>