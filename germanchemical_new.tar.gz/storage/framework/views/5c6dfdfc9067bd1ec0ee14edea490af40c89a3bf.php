<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-header">

<div class="row">
    <div class="col-md-6">
        <h4>Employee</h4>
    </div>

    <div class="col-md-6">
        <a class="btn btn-success float-right" href="/employee/create">New</a>
    </div>
</div>

</div>

    
    <?php if(Session::has('success')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

<?php if(Session::has('failed')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
<?php endif; ?>
                <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>  Email</th>
                        <th> phone</th>
                        <th>  Bio</th>
                        <th>  Image</th>
                        <th>  Designation</th>
                        <th>  Joining Date</th>
                        <th>Action</th>

                    </tr>
                    </thead>


                    <?php ($i=1); ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($res->emp_name); ?> </td>
                        <td><?php echo e($res->emp_email); ?> </td>
                        <td><?php echo e($res->emp_phone); ?></td>
                        <td><?php echo e($res->emp_bio); ?> </td>
                        <td><img src="/images/employee/<?php echo e($res->emp_image); ?>" height="50px "/> </td>
                        <td><?php echo e($res->emp_designation); ?> </td>
                        <td><?php echo e($res->emp_join_date); ?> </td>
                        <td><a class="btn btn-sm btn-info" href="/employee/edit/<?php echo e($res->emp_id); ?>">Edit</a><a class="btn btn-sm btn-danger" href="/employee/delete/<?php echo e($res->emp_id); ?>">Delete</a></td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </table>
            </div>
        </div>



        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/admin/employee/view.blade.php ENDPATH**/ ?>