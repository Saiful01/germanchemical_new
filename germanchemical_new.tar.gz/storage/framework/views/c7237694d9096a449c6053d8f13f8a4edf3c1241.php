<nav id="nav-menu-container">
    <ul class="nav-menu">
        <li class=""><a href="/">Home</a></li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle-mob" href="/" data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">Company <i class="icofont-rounded-down"></i></a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="/companyintro">Company Introduction</a></li>
                <li><a class="dropdown-item" href="/MFChairman">Message From Chairman</a></li>
               
            </ul>
        </li>

     
        <li><a href="/products">Product</a></li>
       

        <li><a href="/career">Career</a></li>
        <li><a href="/contact">Contact</a></li>
        <li><a href="https://germanchemicalsltd.com:2096">Webmail</a></li>
    </ul>
</nav><!-- #nav-menu-container --><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/includes/navbar.blade.php ENDPATH**/ ?>