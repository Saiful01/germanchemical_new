<?php $__env->startSection('title','Products'); ?>



<?php $__env->startSection('content'); ?>

    <section id="services">
        <div class="container">

            <header class="section-header wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                <h3 class="text-center"> PRODUCTS DETAILS</h3>

            </header>

            <div class="row">
                <div class="col-md-9 mx-auto">


                    <img class="details-img" alt="Thumbnail [200x250]"
                         src="/images/product/<?php echo e($result->pro_image); ?>" width="100%">

                    <hr>


                    <h2><?php echo e($result->pro_title); ?></h2>
                    <p style="line-spacing:-5px">
                        <?php echo $result->pro_details; ?>

                    </p>
                <!-- <p>Price: <?php echo e($result->pro_price); ?> tk</p> -->
                </div>


            </div>
        </div>


    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/pages/products/details.blade.php ENDPATH**/ ?>