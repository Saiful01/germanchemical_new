<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">

            <div class="row">
                <div class="col-md-6">
                    <h4>Job</h4>
                </div>

                <div class="col-md-6">
                    <a class="btn btn-success float-right" href="/job/create">New</a>
                </div>
            </div>

        </div>

        <?php if(Session::has('success')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
        <?php endif; ?>

        <?php if(Session::has('failed')): ?>
            <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>#</th>
                <th>job Title</th>
                <th> Description</th>
                <th> Qualification</th>
                <th> Vacancy</th>
                <th> Salary Range</th>
                <th> Experience</th>
                <th> Emp. Status</th>
                <th> Action</th>


            </tr>
            </thead>

            <?php ($i=1); ?>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($res->job_title); ?> </td>
                    <td><?php echo $res->job_description; ?> </td>
                    <td><?php echo e($res->job_qualification); ?> </td>
                    <td><?php echo e($res->job_vacancy); ?></td>
                    <td><?php echo e($res->job_salary); ?></td>
                    <td><?php echo e($res->job_experience); ?></td>
                    <td><?php echo e($res->job_employment_status); ?></td>

                    <td>
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action
                                <span class="caret"></span></button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item btn btn-info" href="/job/edit/<?php echo e($res->job_id); ?>">
                                    Edit
                                </a>
                                <a class="dropdown-item " href="/job/delete/<?php echo e($res->job_id); ?>">
                                    Delete
                                </a>
                                <a class="dropdown-item " href="/jobapplicant/show/<?php echo e($res->job_id); ?>">
                                    Applicant
                                </a>

                                <a class="dropdown-item " href="/job/job-detail/<?php echo e($res->job_id); ?>" target="_blank">
                                    Details
                                </a>


                            </div>


                        <!-- <ul class="dropdown-menu">
    <li><a href="/job/edit/<?php echo e($res->job_id); ?>">Edit</a></li>
    <li><a href="/job/delete/<?php echo e($res->job_id); ?>">Delete</a></li>
    <li><a href="/job/applicant/<?php echo e($res->job_id); ?>">Applicants</a></li>
  </ul> -->
                        </div>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/admin/job/view.blade.php ENDPATH**/ ?>