<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
            <?php endif; ?>

            <?php if(Session::has('failed')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('failed')); ?></p>
            <?php endif; ?>

            <form method="post" action="/product/store" enctype='multipart/form-data'>
                <div class="form-group">
                    <label>Product name:</label>
                    <input type="text" class="form-control" name="pro_title">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                </div>


                <div class="form-group">
                    <label>Product Details:</label>
                    <textarea type="text" class="form-control" id="pro_details" placeholder="Details"
                              name="pro_details"></textarea>
                </div>

                <div class="form-group">
                    <label>Product Image :</label>
                    <input type="file" class="form-control" name="pro_image">
                </div>
                <!--
                                <div class="form-group">
                                    <label>Product Price:</label>
                                    <input type="text" class="form-control" name="pro_price">
                                </div> -->


                <button type="submit" class="btn btn-info">Save</button>
            </form>


        </div>
    </div>
    <script>
        CKEDITOR.replace('pro_details');
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/admin/product/create.blade.php ENDPATH**/ ?>