<?php $__env->startSection('title','Products'); ?>



<?php $__env->startSection('content'); ?>

    <section id="services">
        <div class="container">

            <header class="section-header wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                <h3>OUR PRODUCTS</h3>

            </header>

            <div class="row">

                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card">

                            <div class="card-body">
                                <a href="/pages/products/details/<?php echo e($res->pro_id); ?>">
                                    <img class="card-img-top" src="/images/product/<?php echo e($res->pro_image); ?>" alt="Product image"
                                         width="100%" height="250px">
                                </a>
                                <hr>
                            <!-- <p class="text-success"><b>Price :</b> <?php echo e($res->pro_price); ?> tk</p> -->
                                <p class="headline text-center " style="    margin-bottom: 0px;">
                                    <a class="text-orange font-weight-bold"  href="/pages/products/details/<?php echo e($res->pro_id); ?>"><?php echo e($res->pro_title); ?></a>
                                </p>


                            </div>
                        </div>
                        <br>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pixonlab/Documents/germanchemical_new/resources/views/pages/products/products.blade.php ENDPATH**/ ?>