<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobApplicant extends Model
{
    
    public $timestamps = true; 
    public $guarded = [];
}
