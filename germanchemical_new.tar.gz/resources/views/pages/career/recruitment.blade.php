
@extends('layouts.common')

@section('title','Recruitment')



@section('content')

    <section id="services">
        <div class="container">

            <header class="section-header wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                <h3>Recruitment</h3>

            </header>

            <div class="row">



            </div>
        </div>
    </section>

@endsection