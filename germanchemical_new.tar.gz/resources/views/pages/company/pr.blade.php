
@extends('layouts.common')

@section('title','PR')



@section('content')

    <section id="services">
        <div class="container">

            <header class="section-header wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                <h3>PR</h3>

            </header>

            <div class="row">



            </div>
        </div>
    </section>

@endsection